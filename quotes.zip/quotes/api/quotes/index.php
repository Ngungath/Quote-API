<?php
include_once '../../config/Database.php';

$db = new Database();